package com.likkho.diary

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.runtime.CompositionLocalProvider
import androidx.compose.runtime.staticCompositionLocalOf
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontStyle
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.TextUnit
import androidx.compose.ui.unit.sp

/** Wikipedia-style palette: same hex values as index.css (--wiki-*). */
data class WikiColors(
    val bg: Color, val surface: Color, val border: Color, val hairline: Color,
    val text: Color, val muted: Color, val link: Color, val isDark: Boolean,
) {
    val accent = Color(0xFF3366CC)
    val accentDark = Color(0xFF2A56B0)
    val danger = Color(0xFFB32424)
    val dangerDark = Color(0xFF941D1D)
    val success = Color(0xFF14866D)
}

val LightWiki = WikiColors(
    bg = Color(0xFFFFFFFF), surface = Color(0xFFF8F9FA), border = Color(0xFFA2A9B1), hairline = Color(0xFFEAECF0),
    text = Color(0xFF202122), muted = Color(0xFF54595D), link = Color(0xFF3366CC), isDark = false,
)
val DarkWiki = WikiColors(
    bg = Color(0xFF101418), surface = Color(0xFF1A1F24), border = Color(0xFF3A4047), hairline = Color(0xFF272D34),
    text = Color(0xFFEAECF0), muted = Color(0xFF9AA0A6), link = Color(0xFF6699FF), isDark = true,
)

val LocalWiki = staticCompositionLocalOf { LightWiki }

/**
 * FONTS: React app used Cormorant Garamond (headings), Lora (prose), Plus Jakarta Sans (UI), IBM Plex Mono (dates).
 * Right now these map to system fonts so the project compiles with zero extra files.
 * TODO(StudioAI): download the 4 font families, put the .ttf files in app/src/main/res/font/ and replace the
 * four values below with FontFamily(Font(R.font.xxx, FontWeight.X), ...).
 */
object WikiFonts {
    val serif: FontFamily = FontFamily.Serif          // Cormorant Garamond
    val prose: FontFamily = FontFamily.Serif          // Lora
    val sans: FontFamily = FontFamily.SansSerif       // Plus Jakarta Sans
    val mono: FontFamily = FontFamily.Monospace       // IBM Plex Mono
}

fun serifStyle(size: TextUnit, color: Color, weight: FontWeight = FontWeight.Bold) =
    TextStyle(fontFamily = WikiFonts.serif, fontSize = size, fontWeight = weight, color = color)

fun sansStyle(size: TextUnit, color: Color, weight: FontWeight = FontWeight.Medium) =
    TextStyle(fontFamily = WikiFonts.sans, fontSize = size, fontWeight = weight, color = color)

fun monoStyle(size: TextUnit, color: Color, weight: FontWeight = FontWeight.Normal) =
    TextStyle(fontFamily = WikiFonts.mono, fontSize = size, fontWeight = weight, color = color)

fun proseStyle(size: TextUnit, color: Color, italic: Boolean = false) =
    TextStyle(
        fontFamily = WikiFonts.prose, fontSize = size, color = color,
        fontStyle = if (italic) FontStyle.Italic else FontStyle.Normal,
    )

@Composable
fun LikkhoTheme(dark: Boolean, content: @Composable () -> Unit) {
    val w = if (dark) DarkWiki else LightWiki
    val scheme = if (dark) {
        darkColorScheme(
            primary = w.accent, onPrimary = Color.White, background = w.bg, onBackground = w.text,
            surface = w.surface, onSurface = w.text, outline = w.border, surfaceVariant = w.surface,
            onSurfaceVariant = w.muted,
        )
    } else {
        lightColorScheme(
            primary = w.accent, onPrimary = Color.White, background = w.bg, onBackground = w.text,
            surface = w.surface, onSurface = w.text, outline = w.border, surfaceVariant = w.surface,
            onSurfaceVariant = w.muted,
        )
    }
    CompositionLocalProvider(LocalWiki provides w) {
        MaterialTheme(colorScheme = scheme, content = content)
    }
}

@Composable
fun wiki(): WikiColors = LocalWiki.current

fun parseHex(hex: String): Color? = try {
    if (hex == "default" || hex == "transparent") null else Color(android.graphics.Color.parseColor(hex))
} catch (e: Exception) { null }
