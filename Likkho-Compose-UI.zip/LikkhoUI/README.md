# Likkho — Native Kotlin (Jetpack Compose) UI

React app (Wikilog/Likkho) ka **poora UI/UX** Kotlin Compose me. Features (storage, encryption, backup, recorder, Wikipedia, etc.) **stub** hain — Studio AI banayega.

## Structure (package `com.likkho.diary`)
| File | Kya hai |
|---|---|
| `Theme.kt`, `Common.kt` | Wiki colors (light/dark), square buttons/dialogs/fields, fonts (`WikiFonts`) |
| `Models.kt` | DiaryLog, CanvasImage/Audio, MicSettings, FormatAction, color palettes, export formats |
| `AppViewModel.kt` | Navigation + UI state + passcode cooldown (5th wrong=30s, 6th+=30s*n), pin/delete/export flows |
| **`FeatureHooks.kt`** | **Studio AI yahin kaam karega.** Interface + `StubFeatureHooks` (fake delay/results) |
| `PasscodeScreen.kt` | Lock screen (dots, keypad, biometric key, cooldown, decoy vault by 2nd PIN) |
| `HomeScreen.kt` | Header (search/Lock/menu), list, 3-dot menu, Create FAB, banners, `PfpAvatar` |
| `Dialogs.kt` | Unlock diary, Delete, Export formats, Update, Reminder, Ringing banner |
| `SettingsScreen.kt` | Settings list + Passcode (10s hold = covert 2nd vault), Mic dialog, Passwords, Saved Words, Legal |
| `BackupScreens.kt` | Backup & Restore, Backed-up Diaries (key gate, read, restore, delete) |
| `Workspace.kt`, `RichToolbar.kt`, `Studios.kt` | Canvas editor UI, image/audio control bars, toolbar + all popovers, Image/Audio/PFP studios, Word analysis |
| `LegalContent.kt`, `MathSymbols.kt` | React se auto-convert (same text, 69 LaTeX symbols) |

## Studio AI ke liye prompt
> Is repo me Compose UI ready hai. UI files ko mat badlo. `FeatureHooks.kt` ke har function ka real implementation `RealFeatureHooks` me likho
> (encrypted storage, backup/restore, export, Wikipedia, word analysis, recorder, pickers, reminders, biometric) aur `AppViewModel.hooks` me use karo.
> `// TODO(StudioAI)` comments dekho: real fonts (res/font), photo loading (PfpAvatar, canvas images), rich-text editor
> (Workspace.kt me abhi plain BasicTextField hai), LaTeX render, audio playback, persistence of logs.

## Known limits (honest list)
- Ye code mere yahan **compile nahi hua** (Android SDK/network nahi tha). GitHub Actions me pehli build me chhoti errors (icon name / import) aa sakti hain — Studio AI se fix karwao.
- Fonts system fonts hain (Cormorant/Lora/Jakarta/Plex ke .ttf `res/font` me daalo, `Theme.kt` me swap).
- Workspace text area plain text hai: bold/italic/color etc. buttons sirf UI state dikhate hain.
- Gradle wrapper jar nahi hai; workflow `gradle/actions/setup-gradle` (Gradle 8.7) use karta hai.
- Lock hone par open dialogs lock screen ke upar reh sakte hain (Compose Dialog alag window) — real build me dismiss karna.
- Workspace back button bina save ke exit karta hai (React me bhi `onExitWithoutSave`).
- Demo data `SampleData.kt` me hai; real storage aane par hatao.
